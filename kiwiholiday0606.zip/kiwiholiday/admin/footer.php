     <div class="row text-center" style="background-color: black;height: 150px;">
         <div class="col align-self-center">
           <p style="font-size: 15px;color:white;">©2022 kiwi Holiday, Inc.</p>
         </div>
      </div>