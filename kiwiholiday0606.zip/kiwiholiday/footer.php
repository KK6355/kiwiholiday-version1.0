<div style="color:gray;" id="footer">
        <hr>
        <div class="row justify-content-center">
            <div class="col">
                <h5><b>About Us</b><h5>
                <p style="font-size:15px;">About Kiwi Holiday</p>
                <p style="font-size:15px;">About Hosting</p>
            </div>
            <div class="col text-center">
                <h5><b>Contact Us</b><h5>
                <p style="font-size:15px;">
                <span style="color: #00FFF0;"><i class="fas fa-phone-alt"></i></span>
                &nbsp;0212956355</p>
                <p style="font-size:15px;">
                <span style="color: #00FFF0;"><i class="fas fa-envelope"></i></span>
                &nbsp;kiwiholiday@info.com</p>
            </div>
            <div class="col text-end">
                <h5><b>Follow Us On</b><h5>
                <p style="font-size:15px;">
                <span style="color: #00FFF0;"><i class="fab fa-facebook-square"></i></span>
                &nbsp;@kiwiholidayNZ</p>
                <p style="font-size:15px;">
                <span style="color: #00FFF0;"><i class="fab fa-instagram-square"></i></span>
                &nbsp;@kiwiholidayNZ</p>
            </div>
        </div>
        <br>
        <div class="row text-center">
            <p style="font-size: 12px;">©2022 kiwi Holiday, Inc.</p>
        </div>

</div>